Python bindings for ILM's OpenEXR image file format


